const h = "https://omni-protocol-ai-waittime-production.up.railway.app", o = `${h}/api/v1`, b = `${h}/health`, S = 5e3, p = "omniEarnings", y = "omniUserId";
let d = null;
const s = {
  currency: "INR",
  symbol: "₹",
  tier2Amount: 2,
  tier3Amount: 10,
  minRedemption: 100,
  minWaitSeconds: 5,
  tier3Seconds: 15
}, g = 600 * 1e3;
let l = null, w = 0;
class u extends Error {
  constructor(e, n) {
    super(e), this.status = n, this.name = "BackendError";
  }
}
async function A(t, e = {}) {
  const n = new AbortController(), a = setTimeout(() => n.abort(), S);
  try {
    return await fetch(t, {
      ...e,
      signal: n.signal
    });
  } finally {
    clearTimeout(a);
  }
}
async function r(t, e = {}) {
  const n = await A(t, e), a = await n.json();
  if (!n.ok) {
    let i = `Backend responded with ${n.status}`;
    if (typeof a == "object" && a !== null) {
      const c = a.message;
      typeof c == "string" && c && (i = c);
    }
    throw new u(i, n.status);
  }
  return a;
}
function T(t) {
  return r(`${o}/session/start`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ userId: t })
  });
}
function R(t) {
  return r(`${o}/yield`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(t)
  });
}
function I(t) {
  return r(`${o}/balance/${encodeURIComponent(t)}`);
}
function _(t) {
  return r(`${o}/survey/next/${encodeURIComponent(t)}`);
}
function U() {
  return r(`${o}/ad/next`);
}
function k(t, e, n) {
  return r(`${o}/ad/event`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ adId: t, userId: e, event: n })
  });
}
function $(t, e) {
  const n = new URLSearchParams({ limit: String(e) });
  return r(
    `${o}/transactions/${encodeURIComponent(t)}?${n}`
  );
}
function N(t, e, n) {
  return r(`${o}/redeem`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ userId: t, method: e, detail: n })
  });
}
function C(t) {
  return r(
    `${o}/redemptions/${encodeURIComponent(t)}`
  );
}
function O(t) {
  const e = typeof t == "object" && t !== null ? t.data ?? t : null;
  if (typeof e != "object" || e === null)
    return s;
  const n = e, a = (i, c) => {
    const m = n[i];
    return typeof m == typeof c ? m : c;
  };
  return {
    currency: a("currency", s.currency),
    symbol: a("symbol", s.symbol),
    tier2Amount: a("tier2Amount", s.tier2Amount),
    tier3Amount: a("tier3Amount", s.tier3Amount),
    minRedemption: a("minRedemption", s.minRedemption),
    minWaitSeconds: a("minWaitSeconds", s.minWaitSeconds),
    tier3Seconds: a("tier3Seconds", s.tier3Seconds)
  };
}
async function L() {
  if (l && Date.now() - w < g)
    return l;
  try {
    const t = await r(`${o}/config`), e = O(t);
    return l = e, w = Date.now(), e;
  } catch {
    return s;
  }
}
async function v() {
  const t = await A(b), e = await t.json().catch(() => ({ ok: t.ok }));
  if (!t.ok)
    throw new u(
      `Health endpoint responded with ${t.status}`,
      t.status
    );
  return e;
}
function G(t) {
  if (typeof t == "object" && t !== null) {
    const e = t;
    if (typeof e.balance == "number") return e.balance;
    if (typeof e.data == "object" && e.data !== null) {
      const n = e.data;
      if (typeof n.balance == "number") return n.balance;
    }
  }
  throw new u("Unexpected balance response shape");
}
function P(t) {
  if (Array.isArray(t)) return t;
  if (typeof t == "object" && t !== null) {
    const e = t;
    if (Array.isArray(e.data)) return e.data;
    if (Array.isArray(e.transactions)) return e.transactions;
    if (typeof e.data == "object" && e.data !== null) {
      const n = e.data;
      if (Array.isArray(n.transactions))
        return n.transactions;
    }
  }
  throw new u("Unexpected transactions response shape");
}
function D(t) {
  if (typeof t == "object" && t !== null) {
    const e = t;
    if (Array.isArray(e.redemptions)) return e.redemptions;
    if (typeof e.data == "object" && e.data !== null) {
      const n = e.data;
      if (Array.isArray(n.redemptions))
        return n.redemptions;
    }
  }
  throw new u("Unexpected redemptions response shape");
}
function x(t) {
  return new Promise((e) => {
    chrome.storage.local.get([t], (n) => {
      e(Number(n[t] ?? 0));
    });
  });
}
function f(t) {
  return new Promise((e) => {
    chrome.storage.local.set(t, () => e());
  });
}
function M(t) {
  return new Promise((e) => {
    chrome.storage.local.get([t], (n) => {
      const a = n[t];
      e(typeof a == "string" ? a : void 0);
    });
  });
}
async function E() {
  if (d) return d;
  const t = await M(y);
  if (t)
    return d = t, t;
  const e = crypto.randomUUID();
  return await f({ [y]: e }), d = e, e;
}
async function j(t) {
  const e = await x(p), n = Math.round((e + t) * 100) / 100;
  await f({ [p]: n });
}
async function B(t) {
  const e = await E();
  switch (t.type) {
    case "SESSION_START":
      return { ok: !0, data: await T(e) };
    case "CLAIM_YIELD": {
      const n = await R({ ...t.payload, userId: e });
      return await j(t.payload.amount), { ok: !0, data: n };
    }
    case "GET_SURVEY":
      return { ok: !0, data: await _(e) };
    case "GET_AD":
      return { ok: !0, data: await U() };
    case "AD_EVENT":
      return {
        ok: !0,
        data: await k(
          t.payload.adId,
          e,
          t.payload.event
        )
      };
    case "GET_WALLET": {
      const n = t.payload?.limit ?? 10, [a, i] = await Promise.all([
        I(e),
        $(e, n)
      ]);
      return {
        ok: !0,
        data: {
          balance: G(a),
          transactions: P(i)
        }
      };
    }
    case "GET_HEALTH":
      return { ok: !0, data: await v() };
    case "REDEEM": {
      const n = await N(e, t.payload.method, t.payload.detail);
      return await f({ [p]: 0 }), { ok: !0, data: n };
    }
    case "GET_REDEMPTIONS":
      return {
        ok: !0,
        data: {
          redemptions: D(await C(e))
        }
      };
    case "GET_CONFIG":
      return { ok: !0, data: await L() };
  }
}
chrome.runtime.onInstalled.addListener(() => {
  E();
});
chrome.runtime.onMessage.addListener((t, e, n) => (B(t).then(n).catch((a) => {
  const i = a instanceof u ? a : null;
  n({
    ok: !1,
    error: a instanceof Error ? a.message : "Unknown background error",
    status: i?.status
  });
}), !0));
export {
  R as claimYield,
  E as ensureUserId,
  U as getAdNext,
  I as getBalance,
  v as getHealth,
  C as getRedemptions,
  L as getRewardConfig,
  _ as getSurveyNext,
  $ as getTransactions,
  k as postAdEvent,
  N as postRedeem,
  T as startSession
};
//# sourceMappingURL=worker.js.map
