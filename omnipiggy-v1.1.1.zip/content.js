(function(){"use strict";const $="behavioralLayer",J="behavioralLayer",a="omni-piggy-mindful-break",F="omni-piggy-styles",O=['[aria-label="Stop generating"]','[aria-label*="Stop"]','[data-testid="stop-button"]','button[aria-label="Stop streaming"]'],Z=[{name:"ChatGPT",hosts:["chatgpt.com"],selectors:['[data-testid="stop-button"]','[aria-label="Stop generating"]','button[aria-label="Stop streaming"]']},{name:"Claude",hosts:["claude.ai"],selectors:['button[aria-label="Stop streaming"]','[aria-label*="Stop"]']},{name:"Gemini",hosts:["gemini.google.com"],selectors:['button[aria-label*="Stop"]','button[aria-label*="Cancel"]','button[title*="Stop"]','button[title*="Cancel"]','[role="progressbar"][aria-valuetext]','[role="progressbar"][aria-busy="true"]']},{name:"Perplexity",hosts:["perplexity.ai","www.perplexity.ai"],selectors:['[aria-label*="Stop"]','[data-testid*="stop"]','[data-testid*="typing"]','[data-testid*="cursor"]']},{name:"Copilot",hosts:["copilot.microsoft.com"],selectors:['[aria-label*="Stop"]','[data-testid*="stop"]','button[type="submit"][disabled][aria-label*="Send"]','button[aria-label*="Send"][disabled]']},{name:"DeepSeek",hosts:["chat.deepseek.com"],selectors:['[aria-label*="Stop"]','[data-testid*="stop"]']},{name:"Grok",hosts:["grok.com"],selectors:['[aria-label*="Stop"]','[data-testid*="stop"]']},{name:"Meta AI",hosts:["meta.ai","www.meta.ai"],selectors:['[aria-label*="Stop"]']},{name:"Le Chat",hosts:["chat.mistral.ai"],selectors:['[aria-label*="Stop"]']},{name:"Poe",hosts:["poe.com","www.poe.com"],selectors:['[aria-label*="Stop"]','[data-testid*="stop"]','[data-action*="stop"]']}],ee=12,te=300;let h=null,y=0,S=!1,u=!1,f=!1,d=!1,q=!1,T=null,L=null,C=null,x=!1,v=!1,l=null,E=!1,k=!1,s=null,D=!1;const p={currency:"INR",symbol:"₹",tier2Amount:2,tier3Amount:10,minRedemption:100,minWaitSeconds:5,tier3Seconds:15};let m=null;function g(){try{return!!chrome.runtime?.id}catch{return!1}}function B(){h&&(h.disconnect(),h=null),y&&(cancelAnimationFrame(y),y=0),w(),N()}function W(){return L===null?0:Math.floor((Date.now()-L)/1e3)}function G(e){const t=m??p;return e<t.minWaitSeconds?1:e<t.tier3Seconds?2:3}function ne(e){const t=m??p;return e>=3?t.tier3Amount:t.tier2Amount}function P(e){const t=m??p,n=e%1===0?String(e):e.toFixed(2);return`${t.symbol}${n}`}function w(){C!==null&&(clearInterval(C),C=null)}function H(){w(),C=window.setInterval(()=>{if(!g()){B();return}if(f||d||!S){w();return}u&&_()},1e3)}function A(e){const t=e.querySelector(".omni-survey-options");t&&(t.hidden=!0,t.innerHTML="",delete t.dataset.surveyId)}function oe(e,t,n,i,o){if(!l)return;t.textContent=`💬 Quick Question — earn ${P((m??p).tier3Amount)}`,n.textContent=l.question,n.hidden=!1,i.hidden=!0,o.hidden=!0;const r=e.querySelector(".omni-survey-options");if(r&&r.dataset.surveyId!==String(l.id)){r.dataset.surveyId=String(l.id),r.hidden=!1,r.innerHTML="";for(const c of l.options){const I=document.createElement("button");I.type="button",I.className="omni-survey-option",I.textContent=c,I.addEventListener("click",()=>{U(e,o,{surveyQuestionId:l.id,surveyAnswer:c})}),r.appendChild(I)}}}async function ie(){if(!(x||v)){v=!0;try{const e=await b({type:"GET_SURVEY"});if(x=!0,e.ok){const t=e.data,n=t.success&&t.data?.question?t.data.question:null;n&&n.options.length>=2?l=n:l=null}else l=null}catch{x=!0,l=null}finally{v=!1,u&&!f&&!d&&_()}}}function re(e){const t=e.querySelector(".omni-ad-card");t&&(t.hidden=!0)}async function ae(){if(!(E||k)){k=!0;try{const e=await b({type:"GET_AD"});if(E=!0,e.ok){const t=e.data,n=t.success&&t.data?.ad?t.data.ad:null;n&&n.headline&&n.cta_url?s=n:s=null}else s=null}catch{E=!0,s=null}finally{k=!1,u&&!f&&!d&&_()}}}function M(e){const t=e.querySelector(".omni-ad-card");if(!t)return;if(!s){t.hidden=!0;return}if(t.dataset.adId===String(s.id)){t.hidden=!1;return}t.dataset.adId=String(s.id),t.hidden=!1,t.innerHTML="";const n=document.createElement("p");n.className="omni-ad-label",n.textContent="Sponsored";const i=document.createElement("p");i.className="omni-ad-headline",i.textContent=s.headline;const o=document.createElement("p");o.className="omni-ad-body",o.textContent=s.body;const r=document.createElement("button");r.type="button",r.className="omni-ad-cta",r.textContent=s.cta_label;const c=s;r.addEventListener("click",()=>{b({type:"AD_EVENT",payload:{adId:c.id,event:"click"}}),window.open(c.cta_url,"_blank","noopener")}),t.append(n,i,o,r),D||(D=!0,b({type:"AD_EVENT",payload:{adId:s.id,event:"impression"}}))}function _(){const e=document.getElementById(a);if(!e||d||f)return;const t=e.querySelector(".omni-title"),n=e.querySelector(".omni-body"),i=e.querySelector(".omni-counter"),o=e.querySelector(".omni-claim-btn");if(!t||!n||!i||!o)return;const r=W(),c=G(r);if(c===1){t.textContent="🧘 Mindful Break",n.textContent="Your AI is thinking — take a breath.",n.hidden=!1,i.textContent=`${r}s`,i.hidden=!1,o.hidden=!0,re(e);return}if(n.hidden=!0,i.hidden=!0,o.hidden=!1,c===2){A(e),t.textContent="🧘 Mindful Break",o.textContent=`Claim ${P((m??p).tier2Amount)} Dividend`,!E&&!k&&ae(),M(e);return}if(!x&&!v&&ie(),v&&!x){A(e),t.textContent="💎 Deep Work Bonus",n.hidden=!0,i.hidden=!0,o.hidden=!0,M(e);return}if(l){oe(e,t,n,i,o),M(e);return}A(e),t.textContent="💎 Deep Work Bonus",o.textContent=`Claim ${P((m??p).tier3Amount)} Dividend`,M(e)}function se(){if(document.getElementById(F))return;const e=document.createElement("style");e.id=F,e.textContent=`
    #${a} {
      z-index: 2147483647;
      padding: 18px 20px;
      border-radius: 16px;
      border: 1px solid rgba(57, 255, 136, 0.25);
      background: linear-gradient(145deg, #1a1a1e 0%, #141416 100%);
      box-shadow:
        0 12px 40px rgba(0, 0, 0, 0.45),
        0 0 24px rgba(57, 255, 136, 0.12),
        inset 0 1px 0 rgba(255, 255, 255, 0.06);
      font-family: "Segoe UI", system-ui, -apple-system, sans-serif;
      color: #f4f4f5;
      opacity: 1;
      pointer-events: auto;
    }

    #${a}.omni-floating {
      position: fixed;
      top: 20px;
      right: 20px;
      width: 280px;
      transform: translateX(0);
      transition:
        transform 0.55s cubic-bezier(0.4, 0, 0.2, 1),
        opacity 0.55s cubic-bezier(0.4, 0, 0.2, 1);
    }

    #${a}.omni-inline {
      position: relative;
      display: block;
      max-width: 420px;
      margin: 12px 0;
      width: 100%;
      max-height: 600px;
      overflow: hidden;
      transition:
        opacity 0.55s cubic-bezier(0.4, 0, 0.2, 1),
        max-height 0.55s cubic-bezier(0.4, 0, 0.2, 1),
        margin 0.55s cubic-bezier(0.4, 0, 0.2, 1),
        padding 0.55s cubic-bezier(0.4, 0, 0.2, 1);
    }

    #${a}.omni-floating.omni-slide-out {
      transform: translateX(calc(100% + 32px));
      opacity: 0;
      pointer-events: none;
    }

    #${a}.omni-inline.omni-slide-out {
      opacity: 0;
      max-height: 0;
      margin-top: 0;
      margin-bottom: 0;
      padding-top: 0;
      padding-bottom: 0;
      pointer-events: none;
    }

    #${a} .omni-title {
      margin: 0 0 14px;
      font-size: 17px;
      font-weight: 600;
      letter-spacing: 0.01em;
      color: #ffffff;
    }

    #${a} .omni-body {
      margin: 0 0 10px;
      font-size: 14px;
      line-height: 1.45;
      color: #a1a1aa;
    }

    #${a} .omni-counter {
      margin: 0 0 14px;
      font-size: 12px;
      font-weight: 500;
      letter-spacing: 0.05em;
      color: #71717a;
    }

    #${a} .omni-claim-btn {
      width: 100%;
      padding: 11px 16px;
      border: none;
      border-radius: 10px;
      background: linear-gradient(135deg, #39ff88 0%, #1a9f52 100%);
      color: #0a1a10;
      font-size: 14px;
      font-weight: 700;
      cursor: pointer;
      transition:
        transform 0.15s ease,
        box-shadow 0.15s ease,
        opacity 0.15s ease;
      box-shadow: 0 4px 16px rgba(57, 255, 136, 0.3);
    }

    #${a} .omni-claim-btn:hover:not(:disabled) {
      transform: translateY(-1px);
      box-shadow: 0 6px 20px rgba(57, 255, 136, 0.4);
    }

    #${a} .omni-claim-btn:disabled {
      cursor: default;
      opacity: 0.85;
    }

    #${a} .omni-claim-btn.omni-claimed {
      background: linear-gradient(135deg, #2dd4bf 0%, #059669 100%);
      color: #ffffff;
    }

    #${a} .omni-survey-options {
      display: flex;
      flex-direction: column;
      gap: 8px;
    }

    #${a} .omni-survey-option {
      width: 100%;
      padding: 10px 14px;
      border: 1px solid rgba(255, 255, 255, 0.12);
      border-radius: 10px;
      background: rgba(255, 255, 255, 0.06);
      color: #f4f4f5;
      font-size: 13px;
      font-weight: 500;
      cursor: pointer;
      text-align: left;
      transition:
        background 0.15s ease,
        border-color 0.15s ease;
    }

    #${a} .omni-survey-option:hover:not(:disabled) {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(57, 255, 136, 0.35);
    }

    #${a} .omni-survey-option:disabled {
      cursor: default;
      opacity: 0.6;
    }

    #${a} .omni-check {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
    }

    #${a} .omni-check-icon {
      display: inline-block;
      width: 18px;
      height: 18px;
      border-radius: 50%;
      background: rgba(255, 255, 255, 0.2);
      position: relative;
      animation: omni-pop 0.35s cubic-bezier(0.34, 1.56, 0.64, 1);
    }

    #${a} .omni-check-icon::after {
      content: "";
      position: absolute;
      left: 5px;
      top: 3px;
      width: 5px;
      height: 9px;
      border: solid #fff;
      border-width: 0 2px 2px 0;
      transform: rotate(45deg);
      animation: omni-draw 0.25s ease 0.1s both;
    }

    @keyframes omni-pop {
      0% { transform: scale(0); opacity: 0; }
      100% { transform: scale(1); opacity: 1; }
    }

    @keyframes omni-draw {
      0% { opacity: 0; transform: rotate(45deg) scale(0.5); }
      100% { opacity: 1; transform: rotate(45deg) scale(1); }
    }

    #${a} .omni-ad-card {
      margin-top: 14px;
      padding-top: 12px;
      border-top: 1px solid rgba(255, 255, 255, 0.08);
    }

    #${a} .omni-ad-label {
      margin: 0 0 6px;
      font-size: 9px;
      font-weight: 500;
      letter-spacing: 0.06em;
      text-transform: uppercase;
      color: #71717a;
    }

    #${a} .omni-ad-headline {
      margin: 0 0 4px;
      font-size: 13px;
      font-weight: 600;
      color: #e4e4e7;
      line-height: 1.35;
    }

    #${a} .omni-ad-body {
      margin: 0 0 10px;
      font-size: 12px;
      line-height: 1.4;
      color: #a1a1aa;
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
      overflow: hidden;
    }

    #${a} .omni-ad-cta {
      padding: 6px 12px;
      border: 1px solid rgba(255, 255, 255, 0.18);
      border-radius: 8px;
      background: transparent;
      color: #d4d4d8;
      font-size: 12px;
      font-weight: 500;
      cursor: pointer;
      transition:
        background 0.15s ease,
        border-color 0.15s ease;
    }

    #${a} .omni-ad-cta:hover {
      background: rgba(255, 255, 255, 0.06);
      border-color: rgba(255, 255, 255, 0.28);
    }
  `,document.head.appendChild(e)}function le(e,t){const n=e.toLowerCase();return t.some(i=>{const o=i.toLowerCase();return n===o||n.endsWith(`.${o}`)})}function R(){const e=window.location.hostname;return Z.filter(t=>le(e,t.hosts))}function ce(){return[...R().flatMap(t=>t.selectors),...O]}function z(){for(const e of R())for(const t of e.selectors){const n=document.querySelector(t);if(n)return{element:n,profileName:e.name,selector:t}}for(const e of O){const t=document.querySelector(e);if(t)return{element:t,profileName:"generic",selector:e}}return null}function de(){return z()?.element??null}function ue(e){q||(q=!0,console.debug("[OmniPiggy] matched",e.profileName,e.selector))}function fe(e){for(const t of ce())if(e.querySelector(t))return!0;return!1}function me(){const e=window.location.hostname,t=R();console.log("[OmniPiggy] probe hostname:",e),console.log("[OmniPiggy] active profiles:",t.length>0?t.map(i=>i.name).join(", "):"(none)");for(const i of t)for(const o of i.selectors){const r=document.querySelectorAll(o).length;console.log(`[OmniPiggy] ${r>0?"MATCH":"miss"} profile=${i.name} selector=${o} count=${r}`)}for(const i of O){const o=document.querySelectorAll(i).length;console.log(`[OmniPiggy] ${o>0?"MATCH":"miss"} profile=generic selector=${i} count=${o}`)}const n=z();console.log("[OmniPiggy] findGenerationMatch:",n??"none"),console.log("[OmniPiggy] detectActiveWaitState:",V()),console.log("[OmniPiggy] inline anchor:",Y()?"found":"null (floating fallback)")}window.__omniPiggyProbe=me;function pe(e){const t=e.getBoundingClientRect();if(t.width===0||t.height===0)return!1;const n=window.getComputedStyle(e);return n.display!=="none"&&n.visibility!=="hidden"&&parseFloat(n.opacity)>0}function ge(e){return!!(e.closest('main, [role="main"], article, form, [role="dialog"]')||e.closest('[data-testid*="conversation"], [data-testid*="message"], [data-testid*="thread"], [data-testid*="composer"], [data-testid*="chat"]'))}function Y(){const e=de();if(!e)return null;let t=e.parentElement;for(let n=0;n<ee&&t;n++){if(t.getBoundingClientRect().width>=te&&pe(t)&&ge(t))return t;t=t.parentElement}return null}function V(){const e=z();if(e)return ue(e),!0;if(document.querySelectorAll('[role="progressbar"][aria-valuetext], [role="progressbar"][aria-busy="true"]').length>0)return!0;const n=document.querySelectorAll('button[type="submit"][disabled], button[data-testid="send-button"][disabled], button[data-testid*="send"][disabled], button[aria-label*="Send"][disabled]');for(const i of n){const r=i.closest("form")??document;if(fe(r))return!0}return!1}function N(){const e=document.getElementById(a);e&&e.remove(),u=!1,w()}function be(){return g()?new Promise(e=>{try{chrome.storage.local.get([$],t=>{e(t[$]!==!1)})}catch{e(!0)}}):Promise.resolve(!1)}function he(){if(g())try{chrome.storage.onChanged.addListener((e,t)=>{if(!g()){B();return}t==="local"&&e[$]&&e[$].newValue===!1&&u&&!d&&N()})}catch{}}function Q(){T=null}async function ye(){if(!m){try{const e=await b({type:"GET_CONFIG"});if(e.ok&&typeof e.data=="object"&&e.data!==null){m=e.data;return}}catch{}m=p}}function b(e){return g()?new Promise((t,n)=>{try{chrome.runtime.sendMessage(e,i=>{const o=chrome.runtime.lastError;if(o){n(new Error(o.message));return}if(!i){n(new Error("No background response"));return}t(i)})}catch(i){n(i)}}):Promise.reject(new Error("Extension context invalidated"))}async function xe(){if(g())try{const e=await b({type:"SESSION_START"});if(!e.ok)return;const t=e.data;if(!t.success||!t.data?.sessionToken)return;T=t.data.sessionToken,S&&!f&&j()}catch{}}function ve(){const e=document.createElement("div");e.id=a,e.setAttribute("role","dialog"),e.setAttribute("aria-label","Mindful Break dividend offer");const t=document.createElement("p");t.className="omni-title";const n=document.createElement("p");n.className="omni-body";const i=document.createElement("p");i.className="omni-counter";const o=document.createElement("button");o.type="button",o.className="omni-claim-btn",o.hidden=!0,o.addEventListener("click",()=>void U(e,o));const r=document.createElement("div");r.className="omni-survey-options",r.hidden=!0;const c=document.createElement("div");return c.className="omni-ad-card",c.hidden=!0,e.append(t,n,i,r,o,c),e}function we(e){const t=Y();if(t?.parentElement){e.classList.add("omni-inline"),t.parentElement.insertBefore(e,t);return}e.classList.add("omni-floating"),document.body.appendChild(e)}async function j(){const e=document.getElementById(a);if(e?.isConnected){u=!0;return}if(e&&!e.isConnected&&(e.remove(),u=!1),document.getElementById(a)||f||d||!T||!await be())return;se();const n=ve();we(n),u=!0,_(),C===null&&H()}async function U(e,t,n){if(d)return;d=!0;const i=e.querySelector(".omni-survey-options");i&&i.querySelectorAll("button").forEach(r=>{r.disabled=!0}),t.disabled=!0;const o=n?(m??p).tier3Amount:ne(G(W()));try{const r=await b({type:"CLAIM_YIELD",payload:{amount:o,layer:J,nonce:crypto.randomUUID(),sessionToken:T,...n?{surveyQuestionId:n.surveyQuestionId,surveyAnswer:n.surveyAnswer}:{}}});if(!r.ok)throw r.status===400&&console.error("[OmniPiggy] Survey claim rejected:",r.error),new Error(r.status?`Yield API responded with ${r.status}`:r.error);A(e),t.hidden=!1,t.classList.add("omni-claimed"),t.innerHTML=`
      <span class="omni-check">
        <span class="omni-check-icon" aria-hidden="true"></span>
        Claimed ${P(o)}
      </span>
    `,f=!0,w(),Q(),window.setTimeout(()=>{e.classList.add("omni-slide-out"),window.setTimeout(()=>{N(),d=!1},550)},2e3)}catch(r){console.error("[OmniPiggy] Failed to claim dividend:",r),A(e),t.hidden=!1,t.textContent="Bank offline — Retry",t.disabled=!1,d=!1}}function Se(){if(y=0,!g()){B();return}const e=V();if(e&&!S&&(f=!1,q=!1,x=!1,v=!1,l=null,E=!1,k=!1,s=null,D=!1,L=Date.now(),H(),ye(),xe()),S&&!e&&!f&&(Q(),w(),L=null),S=e,e&&!f){const t=document.getElementById(a);t&&!t.isConnected&&(u=!1),j()}else!e&&u&&!d&&N()}function X(){if(!g()){B();return}y||(y=window.requestAnimationFrame(Se))}function K(){h||(he(),h=new MutationObserver(X),h.observe(document.documentElement,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["aria-label","aria-busy","aria-valuetext","disabled","data-testid","data-action","title","role"]}),X())}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",K,{once:!0}):K()})();
//# sourceMappingURL=content.js.map
